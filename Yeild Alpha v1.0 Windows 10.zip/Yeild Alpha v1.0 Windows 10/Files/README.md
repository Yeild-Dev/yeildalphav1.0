Customized Web Browser
======================
Welcome to my first Open-Source project on Windows Application.
This is a webbrowser created in visual studio 13.The application
is currently in a Beta stage i.e., it is still on development.You
can see the changes of new updates below.

 **********UPDATES AND CHANGES************


Update 1.1.b
------------
*Fixed form unable to move

*Changed the color combination


Update 1.1.a
------------
*Removed Form boder

*Added labels and buttons

*Scripted the buttons and labels

Update 1.0
----------
*Added the form layout

*Changed the style








